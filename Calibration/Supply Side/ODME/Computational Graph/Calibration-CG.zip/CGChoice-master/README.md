# Computational-Graph-based-Choice-Models

This open-source aims to implement automatic differentiation in estimating discrete choice models (TensorFlow)
